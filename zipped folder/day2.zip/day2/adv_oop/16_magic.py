val = 20
print(val + 5)
print(val.__add__(10))
