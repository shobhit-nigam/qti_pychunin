class Bank:
    pass

# pseudo code
class Employee:
    id = 0
    name = ""
    salary = 0
    department = None

    def tax():
        # some code
        pass
