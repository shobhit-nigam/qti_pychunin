"application to fight wars"

import colours

def funcx():
    "function to launch missiles"
    print("in funcx")

class Sample:
    """ a non violent class"""

    data = 20

help(funcx)
help(Sample)
