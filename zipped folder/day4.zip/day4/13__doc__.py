import colours

"use it like comment"

"""some multi line comment
in my domain"""
