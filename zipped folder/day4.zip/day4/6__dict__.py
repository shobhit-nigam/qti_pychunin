varx = 100
varb = ['aa', 'vv', 'rr', 'ii', 'ss']

print(vars())
print("--------")
print(dir())
