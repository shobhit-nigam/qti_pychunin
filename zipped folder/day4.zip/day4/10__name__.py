import os

print(f"__name__ = {__name__}")
print(f"os.__name__ = {os.__name__}")
