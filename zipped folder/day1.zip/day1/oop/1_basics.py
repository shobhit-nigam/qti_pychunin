# pseudo cade
class employee:
    # code for class
    pass
