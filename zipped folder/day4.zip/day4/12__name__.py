import os
import colours

print(f"__name__ = {__name__}")
print(f"colours.__name__ = {colours.__name__}")
