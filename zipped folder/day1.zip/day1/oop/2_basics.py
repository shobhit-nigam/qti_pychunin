varx = 10
name = "chunin"

print(f"type of varx is", type(varx))
print(f"type of varx is", type(name))

def funcx():
    # some code
    pass

print(f"type of funcxx is", type(funcx))
