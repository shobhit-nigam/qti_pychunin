varx = 100
varb = ['aa', 'vv', 'rr', 'ii', 'ss']

def funcx():
    print("in func")
    la = 11
    lb = 22

class Sample:
    data = 90

print(globals())
print("-------")
print(vars(Sample))
