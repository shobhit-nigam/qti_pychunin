"application to fight wars"

def funcx():
    "function to launch missiles"
    print("in funcx")

class Sample:
    """ a non violent class"""

    data = 20

print(f"__doc__ = {__doc__}")
print(f"funcx __doc__ = {funcx.__doc__}")
