"""module for spreading joy through colour"""

def red():
    print("scarlett red")

if __name__ == "__main__":
    def blue():
        print("cool blue")
else:
    def blue():
        print("larger blue")

listd = ['ss', 'ff', 'tt']

__name__ = "vibratnt colours"

blue()
